#pragma once
#include "GeoEllipse.h"

class GeoCirlce : public GeoEllipse
{
public:
	GeoCirlce(double rad);
	void output();
};

