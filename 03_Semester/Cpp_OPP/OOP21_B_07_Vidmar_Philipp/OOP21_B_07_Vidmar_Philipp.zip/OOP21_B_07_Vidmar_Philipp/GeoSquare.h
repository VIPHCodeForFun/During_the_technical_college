#pragma once
#include "GeoRect.h"

class GeoSquare : public GeoRect
{
public:
	GeoSquare(double len);
	void output();
};

