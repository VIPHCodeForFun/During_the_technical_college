#pragma once
#include "Complex.h"
class DComplex :
	public VidP::Complex<double>
{
};

