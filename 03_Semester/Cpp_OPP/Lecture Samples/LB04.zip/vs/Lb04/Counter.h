#pragma once
class Counter {
public:
	int ObjectCount() {
		static int counter = 0;
		return counter++;
	}

	static int ClassCount() {
		static int counter = 0;
		return counter++;
	}

	static int ctr;
};