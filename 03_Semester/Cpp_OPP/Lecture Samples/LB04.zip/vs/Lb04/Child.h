#pragma once
#include "Mother.h"

class Child {
	Mother m{};
};