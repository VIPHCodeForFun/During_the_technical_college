#include "Counter.h"

int Counter::ctr = 0;