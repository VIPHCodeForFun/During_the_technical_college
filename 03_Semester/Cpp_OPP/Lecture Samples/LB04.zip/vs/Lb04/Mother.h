#pragma once
#include <vector>

class Child;
class Mother {
	std::vector<Child> vec{};
};