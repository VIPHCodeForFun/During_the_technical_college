#include "CPersonHack.h"

const std::string CPersonHack::GetName() const
{
    return std::string();
}
