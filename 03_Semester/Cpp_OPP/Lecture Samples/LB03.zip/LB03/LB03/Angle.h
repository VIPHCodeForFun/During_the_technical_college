#pragma once
class Angle {
	float degrees;
public:
	float getDegrees() const;
	void setDegrees(const float& degrees);
};

