#include "CPerson.h"

const std::string CPerson::GetName() const {
	return this->name;
}