#include "Automat.h"
