#include "Abstract.h"

void Concrete::print() const {
	__noop;
}
